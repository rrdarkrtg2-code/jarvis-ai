package com.jarvis.ai.tools

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * STATUS: PLACEHOLDER (Section 64).
 *
 * This class exists now so the manifest declaration and onboarding/permission
 * flow (Sections 5, 37, 55) have a real target to point users at. It does
 * NOT yet read screen content or perform gestures — that is Phase 7
 * (Android automation) and Phase 8 (screen observation). Until then it
 * intentionally does nothing with incoming events.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // NOT POSSIBLE YET: node inspection, tap/scroll dispatch, and
        // before/after screen comparison land in Phase 7/8. No-op for now.
    }

    override fun onInterrupt() {
        // No ongoing operation to interrupt yet.
    }
}
