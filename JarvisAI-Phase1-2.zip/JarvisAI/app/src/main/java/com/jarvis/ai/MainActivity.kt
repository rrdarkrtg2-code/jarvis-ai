package com.jarvis.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.jarvis.ai.navigation.JarvisNavGraph
import com.jarvis.ai.ui.theme.JarvisAITheme
import com.jarvis.ai.ui.theme.JarvisBlack

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JarvisAITheme {
                Surface(
                    modifier = Modifier.fillMaxSize().background(JarvisBlack)
                ) {
                    JarvisNavGraph()
                }
            }
        }
    }
}
