package com.jarvis.ai.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.ai.assistant.AssistantState
import com.jarvis.ai.ui.screens.ChatScreen
import com.jarvis.ai.ui.screens.HomeScreen
import com.jarvis.ai.ui.screens.LoginScreen
import com.jarvis.ai.ui.screens.SettingsScreen
import com.jarvis.ai.ui.screens.TasksScreen
import com.jarvis.ai.viewmodel.JarvisViewModel
import kotlinx.coroutines.delay

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val CHAT = "chat"
    const val TASKS = "tasks"
    const val SETTINGS = "settings"
}

@Composable
fun JarvisNavGraph(
    navController: NavHostController = rememberNavController(),
    viewModel: JarvisViewModel = viewModel()
) {
    val isLoggedIn by viewModel.isOwnerLoggedIn.collectAsState()
    val assistantState by viewModel.assistantState.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val activeTask by viewModel.activeTask.collectAsState()

    NavHost(navController = navController, startDestination = Routes.LOGIN) {
        composable(Routes.LOGIN) {
            LoginScreen(
                onLogin = { id, pw -> viewModel.attemptLogin(id, pw) },
                onLoggedIn = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                state = assistantState,
                onMicTap = {
                    viewModel.startListening()
                },
                onMicCancel = { viewModel.cancelListening() },
                onOpenChat = { navController.navigate(Routes.CHAT) },
                onOpenTasks = { navController.navigate(Routes.TASKS) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                onQuickCommand = { viewModel.sendCommand(it) }
            )
            // Voice capture isn't wired to real speech recognition yet
            // (Phase 4). Simulate a short listening window so the state
            // machine and UI can be exercised end-to-end today.
            SimulateListeningTimeout(assistantState) { viewModel.cancelListening() }
        }
        composable(Routes.CHAT) {
            ChatScreen(
                messages = messages,
                onSend = { viewModel.sendCommand(it) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.TASKS) {
            TasksScreen(
                activeTask = activeTask,
                onStop = { viewModel.stopCurrentTask() },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                ownerName = "RTGYASH",
                onBack = { navController.popBackStack() },
                onLogout = {
                    viewModel.logout()
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
    }
}

@Composable
private fun SimulateListeningTimeout(state: AssistantState, onTimeout: () -> Unit) {
    androidx.compose.runtime.LaunchedEffect(state) {
        if (state == AssistantState.LISTENING) {
            delay(3000)
            onTimeout()
        }
    }
}
