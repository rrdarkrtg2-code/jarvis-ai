package com.jarvis.ai.data.model

enum class Sender { USER, JARVIS }

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class StepStatus { PENDING, RUNNING, DONE, FAILED, WAITING_FOR_USER }

data class TaskStep(
    val id: Long,
    val label: String,
    val status: StepStatus
)

data class JarvisTask(
    val id: Long,
    val title: String,
    val steps: List<TaskStep>,
    val isActive: Boolean
)
