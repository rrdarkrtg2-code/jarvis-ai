package com.jarvis.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jarvis.ai.ui.theme.JarvisRed
import com.jarvis.ai.ui.theme.JarvisSurface
import com.jarvis.ai.ui.theme.JarvisSurfaceElevated
import com.jarvis.ai.ui.theme.JarvisTextSecondary

private data class MenuItem(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String)

private val menuItems = listOf(
    MenuItem(Icons.Default.Settings, "Settings"),
    MenuItem(Icons.Default.RecordVoiceOver, "Voice Assistant"),
    MenuItem(Icons.Default.Apps, "Apps & Tools"),
    MenuItem(Icons.Default.Public, "Web Search"),
    MenuItem(Icons.Default.Folder, "Local Files"),
    MenuItem(Icons.Default.EditNote, "Memory / Notes"),
    MenuItem(Icons.Default.Info, "System Info"),
    MenuItem(Icons.Default.HelpOutline, "Help & About")
)

@Composable
fun SettingsScreen(
    ownerName: String,
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = JarvisSurface), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(JarvisSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("OWNER", style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
                    Text(ownerName, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = JarvisTextSecondary)
            }
        }

        Spacer(Modifier.height(16.dp))

        menuItems.forEach { item ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(14.dp))
                Text(item.label, modifier = Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = JarvisTextSecondary)
            }
            Divider(color = JarvisSurfaceElevated)
        }

        Spacer(Modifier.weight(1f))

        OutlinedButton(
            onClick = onLogout,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisRed),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Icon(Icons.Default.Logout, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("LOG OUT")
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "JARVIS v1.1 · Local Core",
            style = MaterialTheme.typography.labelSmall,
            color = JarvisTextSecondary,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
