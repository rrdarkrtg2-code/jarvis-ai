package com.jarvis.ai.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.assistant.AssistantState
import com.jarvis.ai.data.model.ChatMessage
import com.jarvis.ai.data.model.JarvisTask
import com.jarvis.ai.data.model.Sender
import com.jarvis.ai.data.model.StepStatus
import com.jarvis.ai.data.model.TaskStep
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * PHASE 1/2 STATUS: PARTIALLY IMPLEMENTED.
 *
 * This ViewModel wires real UI state management (state machine, chat log,
 * task list) but `handleCommand` below is a PLACEHOLDER: it does not yet call
 * a real AIProvider, TaskPlanner, or ToolRouter (those land in Phases 5-7).
 * It exists so every screen has a real, observable source of truth to bind
 * to from day one, per the spec's "no fake prototype" rule (Section 64) —
 * the state transitions and chat log are real, only the intelligence behind
 * them is stubbed, and that is called out here explicitly rather than hidden.
 */
class JarvisViewModel : ViewModel() {

    private val _assistantState = MutableStateFlow(AssistantState.IDLE)
    val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(ChatMessage(sender = Sender.JARVIS, text = "How can I help you today?"))
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _activeTask = MutableStateFlow<JarvisTask?>(null)
    val activeTask: StateFlow<JarvisTask?> = _activeTask.asStateFlow()

    private val _isOwnerLoggedIn = MutableStateFlow(false)
    val isOwnerLoggedIn: StateFlow<Boolean> = _isOwnerLoggedIn.asStateFlow()

    /** PLACEHOLDER auth check — real Keystore-backed auth arrives in Phase 3. */
    fun attemptLogin(ownerId: String, password: String): Boolean {
        val success = ownerId.isNotBlank() && password.isNotBlank()
        _isOwnerLoggedIn.value = success
        return success
    }

    fun logout() {
        _isOwnerLoggedIn.value = false
    }

    fun sendCommand(text: String) {
        if (text.isBlank()) return
        _messages.value = _messages.value + ChatMessage(sender = Sender.USER, text = text)
        handleCommand(text)
    }

    /**
     * PLACEHOLDER pipeline. Real version (Section 56) is:
     * input -> normalization -> context analysis -> intent detection ->
     * task planning -> risk check -> permission check -> confirmation if
     * required -> tool execution -> observation -> verification -> response.
     * For now this only demonstrates the state machine and never claims a
     * device action occurred, per Section 46 (no fake capabilities).
     */
    private fun handleCommand(text: String) = viewModelScope.launch {
        _assistantState.value = AssistantState.THINKING
        delay(500)

        _assistantState.value = AssistantState.PLANNING
        val steps = listOf(
            TaskStep(1, "Understand command", StepStatus.DONE),
            TaskStep(2, "Select tool", StepStatus.RUNNING)
        )
        _activeTask.value = JarvisTask(id = System.nanoTime(), title = text, steps = steps, isActive = true)
        delay(500)

        _assistantState.value = AssistantState.ACTING
        delay(400)

        // No real Android tool exists yet in this phase — say so honestly
        // instead of claiming completion (Section 46).
        _assistantState.value = AssistantState.SPEAKING
        val reply = "I understood: \"$text\". Tool execution isn't wired up yet " +
            "(that's Phase 6/7) — right now I can only show you this planning flow."
        _messages.value = _messages.value + ChatMessage(sender = Sender.JARVIS, text = reply)
        _activeTask.value = _activeTask.value?.copy(
            steps = steps.map { it.copy(status = StepStatus.DONE) },
            isActive = false
        )
        delay(600)
        _assistantState.value = AssistantState.IDLE
    }

    fun stopCurrentTask() {
        _activeTask.value = _activeTask.value?.copy(isActive = false)
        _assistantState.value = AssistantState.IDLE
        _messages.value = _messages.value + ChatMessage(sender = Sender.JARVIS, text = "Stopped.")
    }

    fun startListening() {
        _assistantState.value = AssistantState.LISTENING
    }

    fun cancelListening() {
        _assistantState.value = AssistantState.IDLE
    }
}
