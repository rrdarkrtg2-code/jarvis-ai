package com.jarvis.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.assistant.AssistantState
import com.jarvis.ai.ui.components.JarvisOrb
import com.jarvis.ai.ui.theme.JarvisBorder
import com.jarvis.ai.ui.theme.JarvisSurface
import com.jarvis.ai.ui.theme.JarvisTextSecondary

@Composable
fun LoginScreen(
    onLogin: (String, String) -> Boolean,
    onLoggedIn: () -> Unit
) {
    var ownerId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        JarvisOrb(state = AssistantState.IDLE, sizeDp = 150f)
        Spacer(Modifier.height(16.dp))
        Text("JARVIS", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Text(
            "YOUR AI ASSISTANT",
            style = MaterialTheme.typography.labelSmall,
            color = JarvisTextSecondary
        )

        Spacer(Modifier.height(36.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = JarvisSurface),
            border = BorderStroke(JarvisBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("SECURE ACCESS", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text("Authenticate to continue", style = MaterialTheme.typography.bodyMedium, color = JarvisTextSecondary)
                    }
                }

                Spacer(Modifier.height(20.dp))
                Text("Owner / Admin ID", style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
                OutlinedTextField(
                    value = ownerId,
                    onValueChange = { ownerId = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Enter your ID") },
                    singleLine = true
                )

                Spacer(Modifier.height(14.dp))
                Text("Password", style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Enter your password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )

                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }

                Spacer(Modifier.height(22.dp))
                Button(
                    onClick = {
                        if (onLogin(ownerId, password)) onLoggedIn()
                        else error = "Invalid ID or password."
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("LOGIN", letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { /* Owner creation/reset — Phase 3 */ },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("CREATE / RESET OWNER")
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "V1.1 · Local Core · No API Required",
            style = MaterialTheme.typography.labelSmall,
            color = JarvisTextSecondary
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "\"Access granted to those who are worthy.\"",
            style = MaterialTheme.typography.bodyMedium,
            color = JarvisTextSecondary
        )
        Spacer(Modifier.height(24.dp))
    }
}

/** Small helper so we don't pull in the full BorderStroke import chain noisily above. */
private fun BorderStroke(color: Color) = androidx.compose.foundation.BorderStroke(1.dp, color)
