package com.jarvis.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.ai.data.model.JarvisTask
import com.jarvis.ai.data.model.StepStatus
import com.jarvis.ai.ui.theme.JarvisGreen
import com.jarvis.ai.ui.theme.JarvisRed
import com.jarvis.ai.ui.theme.JarvisSurface
import com.jarvis.ai.ui.theme.JarvisTextSecondary

@Composable
fun TasksScreen(
    activeTask: JarvisTask?,
    onStop: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text("Live Task", style = MaterialTheme.typography.titleMedium)
        }

        Spacer(Modifier.height(12.dp))

        if (activeTask == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No active task.", color = JarvisTextSecondary)
            }
            return
        }

        Card(colors = CardDefaults.cardColors(containerColor = JarvisSurface), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(activeTask.title, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (activeTask.isActive) "RUNNING" else "COMPLETED",
                    color = if (activeTask.isActive) MaterialTheme.colorScheme.primary else JarvisGreen,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(activeTask.steps) { step ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val (icon, tint) = when (step.status) {
                        StepStatus.DONE -> Icons.Default.CheckCircle to JarvisGreen
                        StepStatus.FAILED -> Icons.Default.Error to JarvisRed
                        StepStatus.RUNNING -> Icons.Default.Circle to MaterialTheme.colorScheme.primary
                        else -> Icons.Default.Circle to JarvisTextSecondary
                    }
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(step.label)
                }
            }
        }

        Spacer(Modifier.weight(1f))

        if (activeTask.isActive) {
            Button(
                onClick = onStop,
                colors = ButtonDefaults.buttonColors(containerColor = JarvisRed),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Default.Stop, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("STOP TASK")
            }
        }
    }
}
