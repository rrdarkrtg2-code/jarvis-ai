package com.jarvis.ai.assistant

/**
 * Visual/operational state machine for JARVIS (spec Section 25).
 * The orchestrator (added in later phases) will drive transitions between
 * these states as it moves through OBSERVE -> UNDERSTAND -> PLAN -> ACT ->
 * VERIFY -> CONTINUE. The UI layer only ever reacts to this enum — it never
 * decides state on its own.
 */
enum class AssistantState {
    IDLE,
    LISTENING,
    THINKING,
    PLANNING,
    ACTING,
    OBSERVING,
    SPEAKING,
    SUCCESS,
    ERROR,
    WAITING_FOR_USER
}
