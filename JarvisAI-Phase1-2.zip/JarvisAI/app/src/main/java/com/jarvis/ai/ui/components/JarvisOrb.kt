package com.jarvis.ai.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.jarvis.ai.assistant.AssistantState
import com.jarvis.ai.ui.theme.JarvisAmber
import com.jarvis.ai.ui.theme.JarvisCyan
import com.jarvis.ai.ui.theme.JarvisCyanGlow
import com.jarvis.ai.ui.theme.JarvisGreen
import com.jarvis.ai.ui.theme.JarvisMagenta
import com.jarvis.ai.ui.theme.JarvisRed
import kotlin.math.min

/**
 * The central JARVIS visual (spec Section 25 / Section 24). Colors and pulse
 * speed change with [state]; this is the single place that maps assistant
 * state to visual language so every screen looks consistent.
 */
fun stateColor(state: AssistantState): Color = when (state) {
    AssistantState.IDLE -> JarvisCyan
    AssistantState.LISTENING -> JarvisCyanGlow
    AssistantState.THINKING -> JarvisAmber
    AssistantState.PLANNING -> JarvisAmber
    AssistantState.ACTING -> JarvisCyanGlow
    AssistantState.OBSERVING -> JarvisCyan
    AssistantState.SPEAKING -> JarvisMagenta
    AssistantState.SUCCESS -> JarvisGreen
    AssistantState.ERROR -> JarvisRed
    AssistantState.WAITING_FOR_USER -> JarvisAmber
}

@Composable
fun JarvisOrb(
    state: AssistantState,
    modifier: Modifier = Modifier,
    sizeDp: Float = 220f
) {
    val color = stateColor(state)
    val speedMs = when (state) {
        AssistantState.LISTENING, AssistantState.ACTING -> 1400
        AssistantState.THINKING, AssistantState.PLANNING -> 2200
        AssistantState.SPEAKING -> 1000
        else -> 3200
    }

    val transition = rememberInfiniteTransition(label = "orb")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(speedMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(speedMs / 2, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Canvas(modifier = modifier.size(sizeDp.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = min(size.width, size.height) / 2f * pulse

        // Outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(color.copy(alpha = 0.35f), Color.Transparent),
                center = center,
                radius = radius * 1.5f
            ),
            radius = radius * 1.5f,
            center = center
        )

        // Concentric rings
        for (i in 1..3) {
            drawCircle(
                color = color.copy(alpha = 0.25f + 0.15f * i),
                radius = radius * (0.55f + 0.15f * i),
                center = center,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
            )
        }

        // Rotating inner triangle motif (echoes the reference design)
        rotate(rotation, pivot = center) {
            val triRadius = radius * 0.45f
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(center.x, center.y - triRadius)
                lineTo(center.x - triRadius * 0.87f, center.y + triRadius * 0.5f)
                lineTo(center.x + triRadius * 0.87f, center.y + triRadius * 0.5f)
                close()
            }
            drawPath(path, color = color.copy(alpha = 0.9f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx()))
        }

        // Core
        drawCircle(color = color, radius = radius * 0.12f, center = center)
    }
}
