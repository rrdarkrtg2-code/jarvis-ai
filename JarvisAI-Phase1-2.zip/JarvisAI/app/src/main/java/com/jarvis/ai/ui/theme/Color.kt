package com.jarvis.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Core surfaces
val JarvisBlack = Color(0xFF03060A)
val JarvisSurface = Color(0xFF0A1018)
val JarvisSurfaceElevated = Color(0xFF0F1824)

// Brand cyan (idle / listening / structural chrome)
val JarvisCyan = Color(0xFF35D8FF)
val JarvisCyanDim = Color(0xFF1690B0)
val JarvisCyanGlow = Color(0xFF7CF0FF)

// State accents
val JarvisAmber = Color(0xFFFFA733)   // THINKING
val JarvisMagenta = Color(0xFFE23FE0) // SPEAKING
val JarvisGreen = Color(0xFF3CFFA0)   // SUCCESS / ONLINE
val JarvisRed = Color(0xFFFF4D4D)     // ERROR / STOP / destructive

val JarvisTextPrimary = Color(0xFFE8F6FB)
val JarvisTextSecondary = Color(0xFF7C93A3)
val JarvisBorder = Color(0xFF1C3240)
