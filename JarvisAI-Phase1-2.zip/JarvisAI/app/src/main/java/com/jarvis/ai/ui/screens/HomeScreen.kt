package com.jarvis.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.assistant.AssistantState
import com.jarvis.ai.ui.components.JarvisOrb
import com.jarvis.ai.ui.components.stateColor
import com.jarvis.ai.ui.theme.JarvisSurface
import com.jarvis.ai.ui.theme.JarvisTextSecondary

@Composable
fun HomeScreen(
    state: AssistantState,
    onMicTap: () -> Unit,
    onMicCancel: () -> Unit,
    onOpenChat: () -> Unit,
    onOpenTasks: () -> Unit,
    onOpenSettings: () -> Unit,
    onQuickCommand: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("JARVIS", style = MaterialTheme.typography.headlineLarge.copy(fontSize = 22.sp), color = MaterialTheme.colorScheme.primary)
                Text("LOCAL AI CORE v1.1", style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = JarvisTextSecondary)
            }
        }

        Spacer(Modifier.height(24.dp))

        StatusRow(state)

        Spacer(Modifier.weight(1f))

        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxWidth()) {
            JarvisOrb(state = state, sizeDp = 230f)
        }

        Spacer(Modifier.weight(1f))

        if (state == AssistantState.LISTENING) {
            Text("Listening… speak now", color = stateColor(state), modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onMicCancel, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Icon(Icons.Default.Close, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Cancel")
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = JarvisSurface), modifier = Modifier.fillMaxWidth()) {
                Text(
                    "How can I help you today?",
                    modifier = Modifier.padding(16.dp).align(Alignment.CenterHorizontally),
                    color = JarvisTextSecondary
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxWidth()) {
            FloatingActionButton(
                onClick = onMicTap,
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(72.dp)
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Voice", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }

        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            QuickTile(Icons.Default.GraphicEq, "Voice", "Tap to speak", onMicTap)
            QuickTile(Icons.Default.Chat, "Chat", "Type a command", onOpenChat)
            QuickTile(Icons.Default.Apps, "Apps", "Open apps") { onQuickCommand("Open apps") }
            QuickTile(Icons.Default.MoreHoriz, "More", "Quick tools", onOpenTasks)
        }
    }
}

@Composable
private fun StatusRow(state: AssistantState) {
    Card(colors = CardDefaults.cardColors(containerColor = JarvisSurface), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            StatusItem("SYSTEM", if (state == AssistantState.ERROR) "ERROR" else "ONLINE")
            StatusItem("STATE", state.name)
        }
    }
}

@Composable
private fun StatusItem(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
        Text(value, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun QuickTile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, sub: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(JarvisSurface)
        ) {
            Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(sub, style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
    }
}

