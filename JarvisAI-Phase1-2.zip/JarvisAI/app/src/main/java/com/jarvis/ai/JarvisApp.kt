package com.jarvis.ai

import android.app.Application

/**
 * Application entry point. Kept intentionally minimal in Phase 1 — this is
 * where dependency injection (e.g. Hilt) and Room database init will be
 * wired in Phase 10 (Memory) and Phase 47 (architecture) once those layers
 * exist. Declared now so the manifest and later phases don't need to churn.
 */
class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
