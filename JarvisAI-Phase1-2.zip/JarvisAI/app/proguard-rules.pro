# Add project specific ProGuard rules here.
# JARVIS AI release rules will be expanded in Phase 15 (release build).
