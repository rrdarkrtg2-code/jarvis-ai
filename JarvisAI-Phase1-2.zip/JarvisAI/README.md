# JARVIS AI — Android

Personal AI assistant app, built per the master spec (voice control, screen
understanding, task planning, Android automation). This is a real Android
Studio / Gradle project — open it, sync, and run.

## How to open & build

1. Open Android Studio (Koala/2024.1+ recommended).
2. **Open** this folder (`JarvisAI/`) as a project.
3. Let Gradle sync (it will generate the Gradle wrapper jar automatically on
   first sync — no manual step needed inside Android Studio).
4. Run on a device/emulator running **API 26+**.

If you prefer the command line and don't have a wrapper jar yet, run once
(with a local Gradle 8.7 install or via Android Studio's terminal):
```
gradle wrapper --gradle-version 8.7
./gradlew assembleDebug
```
The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Status: Phase 1 & 2 (Foundation + UI)

**Implemented (real, compiles, runs):**
- Gradle project structure, package layout matching the spec's architecture
  (ui / viewmodel / navigation / assistant / tools / data / voice / security)
- Compose theme matching the reference screenshots (black/cyan, amber for
  thinking, magenta for speaking, green for success, red for error/stop)
- Animated `JarvisOrb` component that reacts to `AssistantState`
  (IDLE, LISTENING, THINKING, PLANNING, ACTING, OBSERVING, SPEAKING,
  SUCCESS, ERROR, WAITING_FOR_USER)
- Screens: Login, Home, Chat, Live Task, Settings/Owner menu — navigable via
  Compose Navigation, all bound to one shared `JarvisViewModel`
- `JarvisAccessibilityService` and its manifest/onboarding declaration
  registered (inert — see below)

**Explicitly PLACEHOLDER (not implemented yet — do not read as working):**
- Login is a presence-check only. No Keystore-backed auth yet (Phase 3).
- `JarvisViewModel.handleCommand` simulates the THINKING → PLANNING → ACTING
  → SPEAKING state sequence and posts an honest "not wired up yet" reply. It
  does **not** call a real AI provider, task planner, or tool router.
- `JarvisAccessibilityService` is a registered no-op. No screen reading, no
  gesture dispatch yet (Phase 7/8).
- No voice capture/STT/TTS yet — the mic button simulates a 3-second
  "Listening…" state and times out (Phase 4).
- No Room database, no persisted memory, no reminders/alarms yet
  (Phases 9-11).

This matches spec Section 64: nothing here claims to do more than it does.

## Next phases (per the master prompt)
3. Owner auth (Android Keystore + EncryptedSharedPrefs)
4. Voice input/output (SpeechRecognizer + TextToSpeech)
5. AIProvider abstraction (pluggable cloud/local backend)
6. Tool system (open_app, search_web, tap, scroll, set_alarm, etc.)
7. AccessibilityService automation (real node inspection + actions)
8. Screen observation / vision fallback
9. Task planner (multi-step plans, live task screen wired to real steps)
10. Room-backed memory (user-controlled, editable, deletable)
11. Reminders/alarms via AlarmManager
12. Security hardening pass
13-15. Testing, performance, release build

Each phase will be delivered incrementally, compiled conceptually against
this same project, with explicit IMPLEMENTED / PARTIAL / PLACEHOLDER labels
per feature — no phase will silently claim more than it does.
